package com.uas.sentiment_analysis

object Constants {

    const val SHARED_PREFERENCES_REF_KEY = "BUWEETS_PRIVATE_PREFERENCE_KEY"
    const val SHARED_PREFERENCES_API_URL_KEY = "BUWEETS_PRIVATE_PREFERENCE_KEY_API_URL"
}